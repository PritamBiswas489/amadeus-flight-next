import React from "react";
import style from "./index.module.scss";
import Link from "next/link";
import Image from "next/image";

import sloganIcon from "@/assets/front/images/slogan-icon.jpg";

const BoxThree = () => {
    return (
        <>
            <Link href={"#"} className={style.boxThree}>
                <div className={style.boxThreeTop}>
                    <h6>Lorem Ipsum</h6>
                    <h5>Lorem Ipsum is simply dummy text of</h5>
                    <p>
                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                        when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap
                        into.
                    </p>
                </div>
                <div className={style.boxThreeBtm}>
                    <Image alt="" src={sloganIcon} placeholder="sloganIcon" width={30} height={30} /> Lorem Ipsum
                </div>
            </Link>
        </>
    );
};

export default BoxThree;
